import { createStore, applyMiddleware } from 'redux';
import thunkMiddleware from 'redux-thunk';
import firebase from './Firebase';

const initialState = {
  personData: {},
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "setPersonData":
      return { ...state, personData: action.value };
    case "updateList":
      return { ...state, list: action.value }
    default:
      return state;
  }
}

const store = createStore(reducer, applyMiddleware(thunkMiddleware));

export { store };

//
// Action Creators
//

const setPersonData = (personData) => {
  return {
    type: "setPersonData",
    value: personData
  };
};

const setUserActiveOrderList = (list) => {
  return {
    type: "updateList",
    value: list
  }
}

const watchUserActiveList = (listArr) => {
  return function (dispatch) {
    var actionSetActiveList = setUserActiveOrderList(listArr);
    dispatch(actionSetActiveList);
  }
}

const watchPersonData = (uid) => {
  return function (dispatch) {
    firebase.database().ref("/users/" + uid + "/").on("value", function (snapshot) {
      var personData = snapshot.val();
      var actionSetPersonData = setPersonData(personData);
      dispatch(actionSetPersonData);
    }, function (error) { console.log(error); });
  }
};

const watchRidwrPicked = () => {

}

export { setPersonData, watchPersonData, watchUserActiveList };